###########
# PARTE 2. 
###########

# Elabora un programa completo de la práctica. Siempre puedes usar las versiones más ligeras de los archivos que se utilizan en la práctica. 
# En particular resuelve las preguntas contenidas en la práctica. Discute tus resultados.
# http://datos.langebio.cinvestav.mx/~cei/cursos/R/sesion08adv2.html

# Cargamos lo paquetes

library(IRanges)
library(rtracklayer)
library(GenomicRanges)
library(Rsamtools)

# Primero generamos un objeto base Iranges
x <- IRanges(start=c(11,35,40), end=c(20,50,63)) # Colocamos el inicio y final
x

# Existen diferentes funciones para extraer información de ese objeto 
start(x) # Sólo marca un vector con los valores de inicio
end(x)   # o sólo los finales
width(x) # Ancho de cada rango
range(x) # Rango total de todos
coverage(x) # La cobertura, su suma en cada posición
reduce(x) # Une los rangos que están encimados

# Ahora, para ver la relación de esto 
exons <- reduce(x) # Creamos un objeto que se llame exones
reads <- IRanges(start=c(1,21,30,50,80), width=20) # Otro lecturas 
reads

# Verificamos las coincidencias de esos valores de exones con los de la base de datos en lecturas
countOverlaps(exons, reads)
